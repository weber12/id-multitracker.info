/* Article FructCode.com */



$( document ).ready(function() {
    $("#btn").click(
		function(){
			
			sendAjaxForm('result_form', 'ajax_form', 'https://multitracker.info/?do=api');
			return false; 
		}
	);
});
 
function sendAjaxForm(result_form, ajax_form, url) {
    $.ajax({
        url:     url, //url страницы (action_ajax_form.php)
        type:     "POST", //метод отправки
        dataType: "html", //формат данных
        data: $("#"+ajax_form).serialize(),  // Сеарилизуем объект
        success: function(response) { //Данные отправлены успешно
        	result = $.parseJSON(response);
		
		if (result.status == 'ERROR') {
                var errorTxt;
                if (result.error == 1) {
                    errorTxt = "Не получен параметр."
                } else if (result.error == 2) {
                    errorTxt = "Нужно ввести только цыфры."
                } else if (result.error == 3) {
                    errorTxt = "Торрент с введенным ID не найден."
                }
				//document.querySelector('.timer').style.display = 'none';
				$("#result").css("display","none");
                $('#result').html('<font color="red">Код ошибки: ' + result.error +'</font>  Статус:  ' + errorTxt)/*.hide(2000)*/; 
				//$("#error").css("display","block").show(5000);
            } else if (result.status == 'OK') {
				$("#result").css("display","none");
                $('#result').html('Название: <font color="#f57c00">' + result.name_tor + '</font><br>Размер: <font color="#f57c00">' + result.size_file + '</font><br>Ссылка: <a href=/id/' + result.id_news +' target="_blank">Скачать</a>');
            }

        },
    	error: function(response) { // Данные не отправлены
		    $("#result").css("display","none");
            $('#result').html('Ошибка. Данные не отправлены. Повторите через несколько минут');
    	}
 	});
}
//////
function f() {
	document.querySelector('#result').style.display = 'block';
	document.querySelector('#timer').style.display = 'none';
	}

$( document ).ready(function() {
    $("#btn").click(
		function(){
			
			timer.start(5000); 
		}
	);
});
		
timer = {
  start: function(time) {
    if(typeof(t) == 'undefined') {
     document.querySelector('#timer').style.display = 'block';
    } else {
	  document.querySelector('#timer').style.display = 'block';
      document.querySelector('#result').style.display = 'none';
      clearTimeout(t);
    }
    
    t = setTimeout(function() {f();}, time);
  }
}

