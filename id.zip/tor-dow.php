<?php
if(empty($_GET['id'])){ // переменная $_GET['id'] = NULL
header("HTTP/1.1 301 Moved Permanently"); 
header("Location: /404.html");
exit(); 
//echo "переменная нет";
} else { // переменная $_GET['id'] определена, поэтому меня выполнили
include ($_SERVER['DOCUMENT_ROOT'] . '/config.php');
$id = $_GET['id'];
 if( $curl = curl_init() ) {
    curl_setopt($curl, CURLOPT_URL, "https://multitracker.info/?do=api");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,false);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, "news=".$id);
    $out = curl_exec($curl);
    curl_close($curl);
  }
  $rezult = (array)json_decode ($out);
  //var_dump($rezult);
  if (isset($rezult['name_tor'])) { // переменная $rezult['name_tor'] не NULL, поэтому меня выполнили
  if(empty($config['praefix'])){ 
  $name_tor = $rezult['name_tor']; // имя торрента  
  } else {
  $name_tor = $config['praefix']."_".$rezult['name_tor'];  // имя торрента если есть префикс
  }
  $download = $rezult['download']; // ссылка на загрузку
  //$id_news = $rezult['id_news'];   // ИД новости МультиТрекер
  //$size_file = $rezult['size_file'];// Размер содержимого торрент файла
  //$torrent_size = $rezult['torrent_size']; //размер торрент файла
  //$magnet_link = $rezult['magnet_link']; // magnet_link
  //$torrent_all_leechers = $rezult['torrent_all_leechers']; // Качают
  //$torrent_all_seeders = $rezult['torrent_all_seeders']; // Раздают
  //$torrent_all_completed = $rezult['torrent_all_completed']; //Скачали
  //$md5 = $rezult['md5']; //md5
  //$sha1 = $rezult['sha1'];//sha1
  
        clearstatcache();
     	
	   $ch = curl_init();
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_URL,$download);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt ($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30); 

        $str = curl_exec($ch);
		//print_r($str);
	 
	    curl_close($ch);
	if(empty($str)){ // переменная str = NULL
header("HTTP/1.1 301 Moved Permanently"); 
header("Location: /404.html");
exit(); 
//echo "переменная str пустая";
} else {
	  // заставляем браузер показать окно сохранения файла
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition:  filename=' . $name_tor);
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($str));
    // читаем файл и отправляем его пользователю
    //readfile($str);
	echo $str;
}
 ////////////////////////////////
  } else { // переменная $rezult['name_tor'] = NULL
header("HTTP/1.1 301 Moved Permanently"); 
header("Location: /404.html");
exit(); 
//echo "переменная rezult['name_tor'] пустая";
 }
}
		
?>
