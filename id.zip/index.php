<?php
include ($_SERVER['DOCUMENT_ROOT'] . '/config.php');
if(empty($config['host'])){ 
$host = $_SERVER['HTTP_HOST']; 
} else {
$host = $config['host'];	
}
$HTML = '<!DOCTYPE HTML>
<html>
	<head>
		<title>Скачать Торрент Файл по ID MultiTracker</title>
		<meta charset="utf-8" /> 
		<meta name="description" content="Данный ресурс предоставляет возможность скачать торрент файл по ИД раздачи известного сайта Мультитрекер Инфо. Вам нужно только знать ID торрент файла, остальное мы сделаем за Вас.">
		<meta name="keywords" content="скачать торрент, скачать торрент по иди мультитрекер, скачать с мультитрекера">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="/assets/css/main.css" />
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
        <script src="/assets/js/ajax.js"></script> 
</head>

<body class="is-preload">
	<!-- Header -->
			<header id="header">
				<h1><a href="/">'.strtoupper ($host).'</a></h1>
				<p>Скачивания торрент файла.<br />
				Что бы скачать торрент файл, используйте поле ввода, где укажите нужный ID с MultiTracker.INFO</p>
			</header>
		

     <form method="post" id="ajax_form" action="" >
        <input type="text" name="news" id="email" placeholder="ID MultiTracker.Info" /><br>
        <input type="submit" id="btn" value="ПОЛУЧИТЬ" />
    </form>



    <div id="result_form">
	<div id="timer" style="display: none;"><img src="/img/loading.gif" alt="loading" width="40%" height="40%"></div>
	<div id="result" style="display: none;"></div>
	</div> 
	<div class="index-seo">'.$config['index-seo'].'</div>
   <!-- Footer -->
			<footer id="footer">
				<ul class="icons">
					<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
					<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
					<li><a href="https://github.com/weber12/id-multitracker.info" class="icon fa-github"><span class="label">GitHub</span></a></li>
					<li><a href="#" class="icon fa-envelope-o"><span class="label">Email</span></a></li>
				</ul>
				<ul class="copyright">
					<li>2018  &copy; </li><li><a href="/">'.strtoupper ($host).'</a></li>
				</ul>
			</footer>

		<!-- Scripts -->
			<script src="/assets/js/main.js"></script>
    <script>
    (function flashWord() {
        var seo = document.querySelector(\'.index-seo\').innerText;
        var items = seo.split(\' \');
        var i = 0;

        function run(item) {
            setTimeout(function () {
                document.querySelector(\'.index-seo\').innerHTML = seo.replace(new RegExp(\' \' + item + \' \', \'g\'), \' <span style="color: #999fb9">\' + item + \'</span> \');
                i = getRandom(0, items.length - 1);
                run(items[i].replace(/[^A-Za-zА-Яа-яёЁ0-9]/gim, \'\'));
            }, 100);
        }

        function getRandom(min, max) {
            min = Math.ceil(min);
            max = Math.floor(max);
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }

        run(items[i]);
    })();

</script>
'.$config['Y_Metrika'].'
</body>
</html>';
 
print $HTML;
?>