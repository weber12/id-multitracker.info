<?php
if(empty($_GET['id'])){ // переменная $_GET['id'] = NULL
header("HTTP/1.1 301 Moved Permanently"); 
header("Location: /404.html");
exit(); 
} else { // переменная $_GET['id'] определена, поэтому меня выполнили
include ($_SERVER['DOCUMENT_ROOT'] . '/config.php');
$id = $_GET['id'];
 if( $curl = curl_init() ) {
    curl_setopt($curl, CURLOPT_URL, "https://multitracker.info/?do=api");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,false);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, "news=".$id);
    $out = curl_exec($curl);
    curl_close($curl);
  }
  $rezult = (array)json_decode ($out);
  if (isset($rezult['name_tor'])) { // переменная $rezult['name_tor'] не NULL, поэтому меня выполнили
  if(empty($config['praefix'])){ 
  $name_tor = $rezult['name_tor']; // имя торрента  
  } else {
  $name_tor = $config['praefix']."_".$rezult['name_tor'];  // имя торрента если есть префикс
  }
  //$download = $rezult['download']; // ссылка на загрузку МультиТрекер
  $id_news = $rezult['id_news'];   // ИД новости МультиТрекер
  $size_file = $rezult['size_file'];// Размер содержимого торрент файла
  $torrent_size = $rezult['torrent_size']; //размер торрент файла
  $magnet_link = $rezult['magnet_link']; // magnet_link
  $torrent_all_leechers = $rezult['torrent_all_leechers']; // Качают
  $torrent_all_seeders = $rezult['torrent_all_seeders']; // Раздают
  $torrent_all_completed = $rezult['torrent_all_completed']; //Скачали
  $md5 = $rezult['md5']; //md5
  $sha1 = $rezult['sha1'];//sha1
  $full_link = "/tor-dow.php?id=".$id_news; // ссылка на загрузку
        clearstatcache();
       
	
	
 
if(empty($config['timer'])){ 
$timer = 20; 
} else {
$timer = $config['timer'];	
}
if(empty($config['host'])){ 
$host = $_SERVER['HTTP_HOST']; 
} else {
$host = $config['host'];	
}
///html
$HTML = '<!DOCTYPE html>
<html lang="ru-RU">
<head>
<meta http-equiv="Content-Type" content="text/html; charset={charset}">
<title>'.$name_tor.' :: Скачать файл торрент</title>
<meta name="description" content="Страница скачивания торрент файла '.$name_tor.' по ID MultiTracker.Info." />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="robots" content="noindex, nofollow">
<link href="/assets/css/donowpage.css" type="text/css" rel="stylesheet" />
</head>
<body class="is-preload">

<div class="wrapper">
	<div class="header">'.$config['header_txt'].'</div>

	<div class="main">
		<h1><a href="//'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'">'.$name_tor.'</a></h1>
		<div id="block">
		<div id="line_block">
		<ul>
			<li>Размер: <b>'.$size_file.'</b></li>
			<li>Качают: <b>'.$torrent_all_leechers.'</b></li>
			<li>Раздают: <b>'.$torrent_all_seeders.'</b></li>
			<li>Количество загрузок: <b>'.$torrent_all_completed.'</b></li>
			<li>Размер файла: <b>'.$torrent_size.'</b></li>
			<li>MD5: <b>'.$md5.'</b></li>
			<li>SHA1: <b>'.$sha1.'</b></li>
		</ul>
		</div>
		<div id="line_block" align="center">
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Правый s-rutor -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-8433396301731592"
     data-ad-slot="7369374623"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
		</div>
	</div>
	</div>
	<div class="download_rek">
			<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Малый баннер s-rutor -->
<ins class="adsbygoogle"
     style="display:inline-block;width:234px;height:60px"
     data-ad-client="ca-pub-8433396301731592"
     data-ad-slot="5977838693"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
		</div>
	<div class="download">
			<div class="timer">Подготовка... Ссылка будет доступна через <b>'.$timer.'</b></div>
			<div class="downlink"><a href="'.$full_link.'">Скачать</a></div>
		</div>
	<div class="footer">
		'.date(" Y ").' &copy; <a href="/">'.$host.'</a>
	</div>
</div>

<script>
var timeout = '.$timer.';
var timer = setInterval(function(){
	timeout--;
	document.querySelector(\'.timer b\').innerHTML = timeout;
	if( timeout == 0 ){
		clearInterval(timer);
		document.querySelector(\'.timer\').style.display = \'none\';
		document.querySelector(\'.downlink\').style.display = \'block\';
	}
},1000);
</script>
<script src="/assets/js/main.js"></script>
'.$config['Y_Metrika'].'
</body>
</html>';
 
print $HTML;

 ////////////////////////////////
  } else { // переменная $rezult['name_tor'] = NULL
header("HTTP/1.1 301 Moved Permanently"); 
header("Location: /404.html");
exit(); 
 }
}
		
?>
